const menu = {
  "about": [
    {
      "title": "About",
      "url": "about",
      "children": [
        {
          "title": "Project 65",
          "url": "/project55",
          "inner_children": [
            {
              "title": "Test",
              "url": "/project_scientists/test"
            },
            {
              "title": "Test 2",
              "url": "/project_scientists/test_2"
            },
          ]
        },
        {
          "title": "Project Scientists",
          "url": "/project_scientists",
          "inner_children": [
            {
              "title": "Test",
              "url": "/project_scientists/test"
            },
            {
              "title": "Test 2",
              "url": "/project_scientists/test_2"
            },
            {
              "title": "Test 2",
              "url": "/project_scientists/test_2"
            },
            {
              "title": "Test 2",
              "url": "/project_scientists/test_2"
            },
          ]
        },
        {
          "title": "Institutions",
          "url": "/institutions"
        },
        {
          "title": "Project 65",
          "url": "/project55"
        },
        {
          "title": "Project Scientists",
          "url": "/project_scientists"
        },
        {
          "title": "Institutions",
          "url": "/institutions"
        }
      ]
    }
  ],
  "activities": [
    {
      "title": "Activities",
      "url": "activities",
      "children": [
        {
          "title": "Project 65",
          "url": "/project55"
        },
        {
          "title": "Project Scientists",
          "url": "/project_scientists"
        },
        {
          "title": "Institutions",
          "url": "/institutions"
        },
        {
          "title": "Project 65",
          "url": "/project55"
        },
        {
          "title": "Project Scientists",
          "url": "/project_scientists"
        }
      ]
    }
  ],
  "partners": [
    {
      "title": "Partners",
      "url": "partners",
      "children": [
        {
          "title": "Project 65",
          "url": "/project55"
        },
        {
          "title": "Project Scientists",
          "url": "/project_scientists"
        },
        {
          "title": "Institutions",
          "url": "/institutions"
        },
        {
          "title": "Institutions",
          "url": "/institutions"
        },
      ]
    }
  ],
  "connect": [
    {
      "title": "Connect",
      "url": "connect",
      "children": [
        {
          "title": "Project 65",
          "url": "/project55"
        }
      ]
    }
  ]
}

$(document).ready(function(){ 

  // $('.cookie').addClass('active');

  // $('.cookie__btn').click(function() {
  //   $('.cookie').removeClass('active');
  // })


  $('.nav__link, .hidden').hover(function() {
    $('.hidden').toggleClass('open')

    if($(this).hasClass('nav__link')) {
        $('.hidden__menu').text("");
        let currentItems = [];

        if(currentMenuItem = $(this).data('name')) {
          currentItems = menu[currentMenuItem][0].children;
        } 

        if (currentItems.length > 0) {
            $(this).children(".nav__arrow").toggleClass("active")

            currentItems.forEach(function (item) {

              let itemLink = `<a href="${item.url}" class="hidden__link">${item.title}</a>`;
              let itemSubmenu = '';

              if(item.inner_children && item.inner_children.length > 0) {
                item.inner_children.forEach(function (child) {
                  itemSubmenu += `<a href="${child.url}" class="hidden__link">${child.title}</a>`;
                })
              }

              $(".hidden__menu").append(`<div class="hidden__item">${itemLink}`+ (itemSubmenu ? `<ul class="hidden__list">${itemSubmenu}</ul>` : ''));

            })

            // $('.hidden__item').hover(function() {
            //   console.log($(this))
            //   console.log(currentItems[0].inner_children);
            // })


        } else {
            $('.hidden').removeClass('open')
        }
    }
})

  $(".gallery__img").click(function() {
    var overlay = $("<div id='overlay'></div>");
    overlay.appendTo("body");
    var imgLocation = $(this).attr("src");
    var enlargedImg = $("<img src=" + imgLocation + ">")
    enlargedImg.appendTo(overlay);
    var button = $("<button class='close'>&times;</button>");
    button.appendTo(overlay);
    button.click(function(){
      overlay.remove();
    });
  });

  $('.team__btn').click(function() {
    let aboutText = $(this).siblings(".team__about")

    if(aboutText.hasClass('active')) {
      aboutText.removeClass('active')
      $(this).text("Read more")

    } else {
      aboutText.addClass('active')
      $(this).text("Close")
    }
  })


  $('.projects__slider').slick({
    prevArrow: '<button type="button" class="slick-prev"><img src="img/arrow-left.svg" class="projects__left"></button>',
    nextArrow: '<button type="button" class="slick-next"><img src="img/arrow-right.svg" class="projects__right"></button>',
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 578,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  });


  $('.ham').click(function() {
    $('.side-bar').addClass("open")
  })

  $('.ham__close, .nav__link').click(function() {
    $('.side-bar').removeClass('open')
  })
})
  