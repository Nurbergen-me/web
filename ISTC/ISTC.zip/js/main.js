$(document).ready(function(){ 

  $('.cookie').addClass('active');

  $('.cookie__btn').click(function() {
    $('.cookie').removeClass('active');
  })


  $('.nav__link, .hidden').hover(function() {
    $(this).children(".nav__arrow").toggleClass("active")
    $('.hidden').toggleClass('open') 
  })

  $('.search__open-advanced').click(function() {
    $('.advanced').toggleClass("open")
    $(this).children(".nav__arrow").toggleClass("active")
  })
  
  $('.admin__link_exit').click(function() {
    $(this).children("span").text("Log In")
  })

  $('.nav__login').click(function() {

    if($('.admin').hasClass("open")) {
      $(this).children("span").text("Log In")
    } else {
      $(this).children("span").text("Инжу Белескызы")
    }
    $('.admin').toggleClass("open")
  })


  $('.projects__slider').slick({
    prevArrow: '<button type="button" class="slick-prev"><img src="img/arrow-left.svg" class="projects__left"></button>',
    nextArrow: '<button type="button" class="slick-next"><img src="img/arrow-right.svg" class="projects__right"></button>',
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000
  });

  $('.partners__slider').slick({
    prevArrow: '<button type="button" class="slick-prev"><img src="img/arrow-left.svg" class="projects__left"></button>',
    nextArrow: '<button type="button" class="slick-next"><img src="img/arrow-right.svg" class="projects__right"></button>',
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000
  });
})
  