$(document).ready(function ($) {


  //toggle Post
  $(document).click(function (event) {
    if (!$(event.target).closest(".search-main, btn-wrap button, .after, .enter-btn, .register, .btn-option, .modal-body").length) {
      $('.search-post').removeClass('wid-auto');
      $('.post-btn p').removeClass('d-none');
    }
  });

  $(document).click(function (event) {
    if (!$(event.target).closest(".search-main, .search-post, .after, .enter-btn, .register, .btn-option, .modal-body").length) {
      $('.enter-btn').removeClass('wid-auto');
      $('.for-search').removeClass('wid-long');
    }
  });

  function postClose() {
    $('.search-post').addClass('wid-auto');
    $('.post-btn p').addClass('d-none');
  }

  $('.search-main').click(function () {
    postClose();
    $('.enter-btn').addClass('wid-auto');
    $('.for-search').addClass('wid-long');
  });

  $('.search-after').click(function () {
    $('.enter-btn').addClass('wid-auto');
  })



  //toggle Search

  $(document).click(function (event) {
    if (!$(event.target).closest(".search-post, .after, .enter-btn, .register, .btn-option").length) {
      $('.for-search').removeClass('wid-auto');
      $('.search-input').removeClass('d-none')
      $('.search-after').removeClass('d-none');
      $('.post-wrap').addClass('d-none');
      $('.search-post').removeClass('for-search-post');
      $('.post-btn').removeClass('d-none');
      //$('.enter-btn').removeClass('wid-auto');
    }
  });
  function searchClose() {
    $('.for-search').addClass('wid-auto');
    $('.search-input').addClass('d-none')
    $('.search-after').addClass('d-none');
  }

  $('.search-post').click(function () {
    $('.post-wrap').removeClass('d-none');
    $('.search-post').addClass('for-search-post');
    $('.post-btn').addClass('d-none');
    $('.for-search').removeClass('wid-long');
    searchClose();
  });

  $('.search-post, .post-btn, .btn-wrap button').click(function () {
    $('.enter-btn').addClass('wid-auto');
  })


  // toggle form


  $('.enter-btn').click(function (e) {
    $('.enter-btn').removeClass('wid-auto');
    $('.post-wrap').addClass('d-none');
    $('.search-post').removeClass('for-search-post');
    postClose();
    searchClose();
    $('.enter-btn').addClass('for-enter-btn');
    $('.form-wrapper').removeClass('d-none');
    if (!$(e.target).hasClass('modal_registration')) {
      setTimeout(function () {
        $('.enter-btn').addClass('for-enter');
      }, 300);
    }
  })


  $(document).click(function (event) {
    if (!$(event.target).closest(".enter-btn, .register, .btn-option, .search-hidden").length) {
      $('.enter-btn').removeClass('for-enter-btn for-enter');
      $('.form-wrapper').addClass('d-none');

    } else if ($(event.target).closest('.modal_registration').length) {
      $('.enter-btn').removeClass('for-enter-btn for-enter');
      $('.form-wrapper').addClass('d-none');
      $('.enter-btn').addClass('wid-auto');
    }
  });


  $('.ui-autocomplete-input').keydown(function () {
    if ($('.ui-autocomplete-input').val().length > 0) {
      $('.ui-autocomplete-input').addClass('focus-input');
    } else {
      $('.ui-autocomplete-input').removeClass('focus-input');
    }
  });


  // Меню 
  $('.nav-burg-icon').click(function () {
    if ($('.nav-account').hasClass('show-account')) {
      $('.nav-account').removeClass('show-account');
      $('.nav-menu').toggleClass('nav-menu-change');
    } else {
      $('.nav-hidden-wrapper').toggleClass('open-hidden-wrapper');
      $('.nav-menu').toggleClass('nav-menu-change');
    }
  });

  $(document).click(function (event) {
    if (!$(event.target).closest(".menu-wrapper").length) {
      changeAccClose()
      $('.nav-hidden-wrapper').removeClass('open-hidden-wrapper');
      $('.nav-menu').removeClass('nav-menu-change');
      $('.submenu-wrapper').removeClass('submenu-show');
      $('.nav-arrow').removeClass('nav-active');
    }
  });

  $('.nav-arrow').click(function () {
    $('.submenu-wrapper').toggleClass('submenu-show');
    $('.nav-arrow').toggleClass('nav-active');
    changeAccClose()
  })

  function changeAccClose() {
    $('.nav-account').removeClass('show-account');
    $('.nav-menu').addClass('nav-menu-change');
  }
  $('.change-acc').click(function () {
    $('.nav-account').toggleClass('show-account');
    $('.nav-menu').toggleClass('nav-menu-change');
  })

  $('.nav-account-item').click(function (e) {
    $('.nav-account-item').removeClass('account-choosen');
    $(e.target).closest('div').addClass('account-choosen');
    $('.item-request').toggleClass('hidden-item');
  });

  // Слайдер
  var slideNow = 1;
  $('.slider-control span').hover(function () {
    translate = $('img.activeSlide').width();
    var circleIndex = $(this).index();
    $('.slider-control span').removeClass('active');
    $(this).addClass('active');
    // Перемещение слайдера
    if (circleIndex + 1 != slideNow) {
      translate = translate * circleIndex;
      $(this).parent().prev().children().css({
        'transform': 'translateX(-' + translate + 'px)',
        '-webkit-transform': 'translateX(-' + translate + 'px)',
        '-ms-transform': 'translateX(-' + translate + 'px)',
      });
    }
    slideNow = circleIndex + 1;
  }, function () {
    //sdf
  });
})